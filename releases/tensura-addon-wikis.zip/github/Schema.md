# Schema

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Home) · [Tensura Myths](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Tensura-Myths)

A Battlewill with a customizable six-effect tree. Learn: 1,000 points. Master: 2,000 points.

![Schema icon](https://github.com/Bithio999/TensuraAdditionalAdditions/raw/refs/heads/main/wiki/assets/battlewill/schema.png)

| Skill data | Value |
| --- | --- |
| Tier | Battlewill |
| Damage type | None |


<a id="schema-tree"></a>

<a id="build"></a>

## Use

Press Build to open the tree. Choose Add Mito, Add Str. or Add Regen; select a slot to move or remove it. Apply saves; Close discards unapplied edits. Toggle Schema to activate the saved tree.


## Effects per stack

- Mitochondrial: +500% aura regeneration; −5% outgoing damage.
- Strength: +5 base attack damage; +2% damage taken.
- Regenerative: +20% HP/SHP healing received; +5% aura and magicule costs. Healing bonuses apply once and respect native limits.

## Slot order and mastery

Positive weights start at 100%, 50%, 25%, 12.5%, 6.25%, 3.125%. Every 400 mastery makes another slot full strength, reaching all six at 2,000. All effects share that order; drawbacks always stay full strength.

Chained/Unbound boosts positive Battlewill bonuses once; drawbacks are not boosted.


## Training

Qualifying aura recovery, Strength hits and Regenerative healing share one mastery gain every 30 seconds. Idle full reserves, editing and toggling grant no training. The timer and build persist after saving.


## Related

[Chained](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Chained) · [Unbound](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Unbound) · [Aura regeneration](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Aura-Regeneration)

## Pictures and video

![Schema — schema regenerative mastered build](https://github.com/Bithio999/TensuraAdditionalAdditions/raw/refs/heads/main/wiki/media/schema-regenerative-mastered-build.png)
