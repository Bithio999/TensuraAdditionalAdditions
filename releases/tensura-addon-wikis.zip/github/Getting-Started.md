# Getting started

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Home) · [Tensura Myths](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Tensura-Myths)

Install **Java 21**, **Minecraft 1.21.1 / NeoForge 21.1.209+**, **Tensura 2.0.1.3** and its required libraries, then add [Tensura Myths 0.36.1](https://github.com/Bithio999/TensuraAdditionalAdditions/raw/refs/heads/main/releases/tensura-myths-0.36.1.jar). Myths also requires **GeckoLib 4.9.3 (4.x)**. Update both client and server for multiplayer.

Choose a race in Tensura’s reincarnation menu. The eight [Unique skills](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Unique-Skills) join its starting rolls; no trial is required. Pick **Fettered Human** only if you want the restrictions and physical combat of [Chained](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Chained).

Use Tensura’s normal skill menu for equipped arts and passive toggles. Press **F8** for the [in-game guide](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/In-Game-Guide).

Do not install TensuraAdditionalAdditions in the same instance. [Choose the correct mod](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Home).
