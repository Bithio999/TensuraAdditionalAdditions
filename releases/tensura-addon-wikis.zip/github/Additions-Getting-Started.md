# Getting started

[All wikis](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Home) · [TensuraAdditionalAdditions](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/TensuraAdditionalAdditions)

Install **Java 21**, **Minecraft 1.21.1 / NeoForge**, **Tensura 2.0.1.3–2.0.1.5** and its required libraries, plus **GeckoLib 4.9.2+ (4.x)**. Add [TensuraAdditionalAdditions 1.31.4](https://github.com/Bithio999/TensuraAdditionalAdditions/raw/refs/heads/main/releases/TensuraAdditionalAdditions-1.31.4.jar) and remove older copies. Install matching versions on client and server. Tensura Myths must not be installed alongside it.

For Heavenly Restriction, select **Fettered Human** at reincarnation; it starts with Chained. [The lineage page](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Additions-Fettered-Human) lists evolution requirements.

The addon works with **Tensura Neo Otherworld 1.1.3a**. That pack’s **Restricted Human** is Mysticism’s separate race; choose **Fettered Human** for this addon’s lineage. [Pack compatibility](https://github.com/Bithio999/TensuraAdditionalAdditions/blob/main/standalone/tensura-additional-additions/docs/compatibility/NEO-OTHERWORLD-1.1.3a.md).

Press **F8** for the [in-game guide](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Additions-In-Game-Guide). [Parallel World Jumper](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Additions-Parallel-World-Jumper) is private single-player only; the remaining content supports multiplayer when both client and server have the addon.
