# Ossuary Runesmith

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](../README.md) · [Tensura Myths](Tensura-Myths.md)

**Ossuary Runesmith** is the unique Convergent race formed from **Dwarf** and **Wight** ancestry. Dwarf vitality and Wight spirit form a single stable lineage.

![Race icon](../assets/race/convergence/dwarf_wight.png)

| Race data | Value |
| --- | --- |
| Ancestries | Dwarf + Wight |
| Alignment | Chaos |
| Aura gain weight | 3.225 |
| Magicule gain weight | 2.775 |
| Growth at a baseline of 3, including +10% | 10.6425 aura / 9.1575 magicules |

## Obtaining

Finish both ancestral evolution paths, become a True Hero or True Demon Lord, and meet the fixed EP gate shown in the **Convergent Awakening** tab (at least 10M EP). Awakening grants a one-time +25% to both base energy pools and retains learned skills and the +10% EP gain bonus.

## Racial ability

**Concordance Pulse — no damage.** Heal 50% maximum HP and SHP, without a fixed amount cap, and push nearby enemies. Cost: **1,500 aura**. Cooldown: **30 seconds**. Healing stops at your current maximums.

Traits combine both final ancestries. [Awakening details and shared traits](Convergent-Awakening.md).
