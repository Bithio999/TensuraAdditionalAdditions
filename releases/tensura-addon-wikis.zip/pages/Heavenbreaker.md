# Heavenbreaker

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](../README.md) · [Tensura Myths](Tensura-Myths.md)

**Heavenbreaker** is evolution 4 of four of the **Heavenly Restriction** lineage. A human-looking martial body exchanges magical growth for exceptional physical and aura potential through **Chained**, the Unique Skill inherited from Fettered Human.

| Race data | Value |
| --- | --- |
| Ancestry | Human |
| Stage | 4 / 4 evolutions |
| Recovery Extra | [Sovereign Rebirth](Sovereign-Rebirth.md) |
| Retained Unique | [Chained](Chained.md); granted only by Fettered Human |
| HP racial bonus | +1,000 |
| SHP racial bonus | +6,600 |
| Attack bonus | +16 |
| Movement bonus | +30% of base movement |
| Knockback resistance bonus | +0.6 |
| Previous evolution | [Heavenly Restricted](Heavenly-Restricted.md) |
| Next evolution | Final stage |

## Evolution

[Heavenly Restriction progression](Fettered-Human.md). Racial bonuses replace earlier stages; they do not stack.
